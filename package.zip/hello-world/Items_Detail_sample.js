define(function () {
	// Detail View
	const VIEW_OITM_DETAIL = "fb229f12-b37f-4215-8550-df1889e5bf59";
	
	const UUID_BTN_HELLO_WORLD = "uuid_btn_hello_world";
	const CONTROL_UUID = "idoc_sample_StringInput";
	

	async function loadHelloWorld(oInst) {
		oInst.showMessageBox("Success", "Hello World - Item Loaded", [{
			label: "OK",
			key: "OK"
		}]);
		let oView = oInst.ActiveView("fb229f12-b37f-4215-8550-df1889e5bf59");
		await oView.TimePicker(TimePicker).setValue(10);
	}

	async function myHelloWorldClicked(oInst) {
		oInst.showMessageBox("Success", "Hello World Button Clicked ", [{
			label: "OK",
			key: "OK"
		}]);

	}

	async function samplefunction(oInst,...args) {
        let control = oInst.ActiveView("uuid_hello_world").StringInput(CONTROL_UUID);
		let x = await control.getValue();
		console.debug(x);
		await control.setValue(value);
		}
	async function samplefunction(oInst,...args) {
		let id = oInst.ActiveView("uuid_hello_world").TimePicker(TimePickerID).getVisible();
		let x = await control.getValue();
		console.debug(x);		
		await control.setValue(value);
		
			}
		

	// Event names
	const onAfterFormOpen = `OnAfterOpenForm`;
	const onAfterButtonClickBtnHelloWorld = `on${UUID_BTN_HELLO_WORLD}AfterButtonClick`;

	const ChangeEventName= `on${CONTROL_UUID}Change`;

	return {
		[onAfterFormOpen]: async function (oInst) {
			await loadHelloWorld(oInst);
		},
		[onAfterButtonClickBtnHelloWorld]: async function (oInst) {
			await myHelloWorldClicked(oInst);
		},
		[ChangeEventName]: async function(oInst, ...args) {
            await samplefunction(oInst,...args);
        }
		
	};
	layout: {
		properties: [{
			label: "123",
			name: "123",
			type: "ONE2MANY",
			properties: [
				{
					name: "CheckboxRounding",
					type: "CHECKBOX"
				},
			
			]
		}]
	};

